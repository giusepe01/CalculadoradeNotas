package com.example.calculadoradenotas;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText textInputNota1;
    EditText textInputNota2;
    EditText textInputNota3;
    TextView textView3;
    Button btnCalcular;

    //valores de variaveis
    Double AP1;
    Double AP2;
    Double AP3;
    Double Resultado;
    Double Media;
    Double Resto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textInputNota1 = (EditText) findViewById(R.id.txtNota1);
        textInputNota2 = (EditText) findViewById(R.id.txtNota2);
        textInputNota3 = (EditText) findViewById(R.id.txtNota3);
        textView3 = (TextView) findViewById(R.id.textView3);
        btnCalcular = (Button)findViewById(R.id.btnCalcular);
    }

    public Double CalcularNota(View view) {

        if (textInputNota1.getText().toString().trim().equals("") && textInputNota2.getText().toString().trim().equals("") && textInputNota3.getText().toString().trim().equals("")) {
            Toast.makeText(this, "Todos as notas estão vazias!", Toast.LENGTH_LONG).show();
            textView3.setText(null);
        } else if (textInputNota1.getText().toString().trim().equals("")) {
            Toast.makeText(this, "A nota 1 está vazia!", Toast.LENGTH_LONG).show();
            textView3.setText(null);
        } else if (textInputNota2.getText().toString().trim().equals("")) {
            Toast.makeText(this, "A nota 2 está vazia!", Toast.LENGTH_LONG).show();
            textView3.setText(null);
        } else if (textInputNota3.getText().toString().trim().equals("")) {
            AP1 = Double.parseDouble(textInputNota1.getText().toString());
            AP2 = Double.parseDouble(textInputNota2.getText().toString());

            if (AP1 < 0 || AP1 > 10) {
                Toast.makeText(this, "Nota 1 com valor inválido!", Toast.LENGTH_LONG).show();
                textView3.setText(null);

            } else if (AP2 < 0 || AP2 > 10) {
                Toast.makeText(this, "Nota 2 com valor inválido!", Toast.LENGTH_LONG).show();
                textView3.setText(null);

            } else {
                Media = (AP1 * 0.3) + (AP2 * 0.3);
                textView3.setText(Media.toString());
            }

        } else {
            AP1 = Double.parseDouble(textInputNota1.getText().toString());
            AP2 = Double.parseDouble(textInputNota2.getText().toString());
            AP3 = Double.parseDouble(textInputNota3.getText().toString());

            if (AP1 < 0 || AP1 > 10) {
                Toast.makeText(this, "Nota 1 com valor inválido!", Toast.LENGTH_LONG).show();
                textView3.setText(null);

            } else if (AP2 < 0 || AP2 > 10) {
                Toast.makeText(this, "Nota 2 com valor inválido!", Toast.LENGTH_LONG).show();
                textView3.setText(null);

            } else if (AP3 < 0 || AP3 > 10) {
                Toast.makeText(this, "Nota 3 com valor inválido!", Toast.LENGTH_LONG).show();
                textView3.setText(null);

            } else {
                Media = (AP1 * 0.3) + (AP2 * 0.3) + (AP3 * 0.4);
                textView3.setText(Media.toString());
            }}
            return Media;
        }

        public void CalcularQuestoesAP3 (View view)
        {
            if (textInputNota1.getText().toString().trim().equals("") && textInputNota2.getText().toString().trim().equals("")) {
                Toast.makeText(this, "Todos as notas estão vazias!", Toast.LENGTH_LONG).show();
                textView3.setText(null);
            } else if (textInputNota1.getText().toString().trim().equals("")) {
                Toast.makeText(this, "A nota 1 está vazia!", Toast.LENGTH_LONG).show();
                textView3.setText(null);
            } else if (textInputNota2.getText().toString().trim().equals("")) {
                Toast.makeText(this, "A nota 2 está vazia!", Toast.LENGTH_LONG).show();
                textView3.setText(null);
            } else if (!textInputNota3.getText().toString().trim().equals("")) {
                Toast.makeText(this, "Você ja fez a AP3!", Toast.LENGTH_LONG).show();
                textView3.setText(null);
            } else {
                AP1 = Double.parseDouble(textInputNota1.getText().toString());
                AP2 = Double.parseDouble(textInputNota2.getText().toString());

                Media = (AP1 * 0.3) + (AP2 * 0.3);


                if (Media > 5) {
                    Toast.makeText(this, "Você não está dependendo da AP3 para passar, este app não é para você!!!", Toast.LENGTH_LONG).show();
                    textView3.setText(null);

                } else if (Media == 5) {
                    Toast.makeText(this, "Você não está dependendo da AP3 para passar, você já passou com 5.", Toast.LENGTH_LONG).show();
                    textView3.setText(null);
                } else {
                    Resto = (((5 - Media) / 0.4) / 0.4);
                    Toast toast = Toast.makeText(this, "Você precisa acertar " + Math.round(Resto) + " Questões para tirar 5", Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL, 0, 0);
                    toast.show();
                }
            }
        }
    }
